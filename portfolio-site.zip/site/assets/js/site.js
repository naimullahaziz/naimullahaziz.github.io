/* ==========================================================================
   Na'imullah Aziz — portfolio
   Satu file JS untuk semua halaman. Tanpa library, tanpa jQuery.
   ========================================================================== */
(function(){
  "use strict";
  var still = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var each  = function(list, fn){ Array.prototype.forEach.call(list, fn); };

  /* ---------- 1. menu mobile ---------- */
  var toggle = document.querySelector('.navtoggle'),
      nav    = document.getElementById('nav');
  if(toggle && nav){
    toggle.addEventListener('click', function(){
      var open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    each(nav.querySelectorAll('a'), function(a){
      a.addEventListener('click', function(){
        nav.classList.remove('open');
        toggle.setAttribute('aria-expanded','false');
      });
    });
  }

  /* ---------- 2. bar progres scroll ---------- */
  var prog = document.querySelector('.progress span'), queued = false;
  if(prog){
    var paint = function(){
      var h = document.documentElement.scrollHeight - window.innerHeight;
      prog.style.transform = 'scaleX(' + (h > 0 ? Math.min(window.scrollY / h, 1) : 0) + ')';
      queued = false;
    };
    window.addEventListener('scroll', function(){
      if(!queued){ queued = true; requestAnimationFrame(paint); }
    }, {passive:true});
    paint();
  }

  /* ---------- 3. gambar belum ada jadi placeholder rapi ---------- */
  var flag = function(img){
    var box = img.closest('.media') || img.closest('.slide');
    if(box) box.classList.add('empty');
  };
  each(document.querySelectorAll('.media img, .slide img'), function(img){
    img.addEventListener('error', function(){ flag(img); });
    if(img.complete && img.naturalWidth === 0) flag(img);
  });

  /* ---------- 4. slideshow hero ---------- */
  var stage = document.querySelector('.stage');
  if(stage){
    var slides = stage.querySelectorAll('.slide'),
        dots   = stage.querySelector('.dots'),
        cur = 0, timer = null;

    if(slides.length){
      slides[0].classList.add('on');

      each(slides, function(s, i){
        var b = document.createElement('button');
        b.type = 'button';
        b.setAttribute('aria-label', 'Slide ' + (i + 1));
        b.setAttribute('aria-current', i === 0 ? 'true' : 'false');
        b.addEventListener('click', function(){ go(i); restart(); });
        dots.appendChild(b);
      });

      var go = function(i){
        slides[cur].classList.remove('on');
        dots.children[cur].setAttribute('aria-current','false');
        cur = (i + slides.length) % slides.length;
        slides[cur].classList.add('on');
        dots.children[cur].setAttribute('aria-current','true');
      };
      var start   = function(){ if(!still && !timer && slides.length > 1) timer = setInterval(function(){ go(cur + 1); }, 5200); };
      var stop    = function(){ clearInterval(timer); timer = null; };
      var restart = function(){ stop(); start(); };

      stage.addEventListener('mouseenter', stop);
      stage.addEventListener('mouseleave', start);
      stage.addEventListener('focusin', stop);
      stage.addEventListener('focusout', start);
      document.addEventListener('visibilitychange', function(){ document.hidden ? stop() : start(); });

      var x0 = null;
      stage.addEventListener('touchstart', function(e){ x0 = e.touches[0].clientX; stop(); }, {passive:true});
      stage.addEventListener('touchend', function(e){
        if(x0 === null) return;
        var d = e.changedTouches[0].clientX - x0;
        if(Math.abs(d) > 45) go(cur + (d < 0 ? 1 : -1));
        x0 = null; start();
      }, {passive:true});

      start();
    }
  }

  /* ---------- 5. muncul saat discroll ---------- */
  var reveals = document.querySelectorAll('.reveal');
  if(still || !('IntersectionObserver' in window)){
    each(reveals, function(el){ el.classList.add('in'); });
  } else {
    each(document.querySelectorAll('.stagger'), function(group){
      each(group.querySelectorAll('.reveal'), function(el, i){
        el.style.setProperty('--d', Math.min(i, 6) * 0.08 + 's');
      });
    });
    var io = new IntersectionObserver(function(entries){
      entries.forEach(function(en){
        if(en.isIntersecting){ en.target.classList.add('in'); io.unobserve(en.target); }
      });
    }, {rootMargin:'0px 0px -10% 0px', threshold:0.06});
    each(reveals, function(el){ io.observe(el); });
  }

  /* ---------- 6. video YouTube, dimuat hanya saat diklik ---------- */
  each(document.querySelectorAll('.media.vid'), function(fig){
    var id = fig.getAttribute('data-yt');
    if(!id || id === 'YOUTUBE_ID'){ fig.classList.add('empty'); return; }
    var thumb = new Image();
    thumb.src = 'https://i.ytimg.com/vi/' + id + '/hqdefault.jpg';
    thumb.alt = ''; thumb.loading = 'lazy';
    fig.insertBefore(thumb, fig.firstChild);
    var play = document.createElement('div');
    play.className = 'play';
    fig.appendChild(play);
    var load = function(){
      fig.innerHTML = '<iframe src="https://www.youtube-nocookie.com/embed/' + id +
        '?autoplay=1&rel=0" title="Video" allow="accelerometer; autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>';
    };
    fig.addEventListener('click', load);
    fig.addEventListener('keydown', function(e){
      if(e.key === 'Enter' || e.key === ' '){ e.preventDefault(); load(); }
    });
  });

  /* ---------- 7. lightbox ---------- */
  var lb = document.querySelector('.lb');
  if(lb){
    var lbimg = lb.querySelector('img'),
        lbcap = lb.querySelector('.cap'),
        opener = null;

    var open = function(fig){
      var img = fig.querySelector('img'), cap = fig.querySelector('figcaption');
      if(!img) return;
      opener = fig;
      lbimg.src = img.currentSrc || img.src;
      lbcap.textContent = cap ? cap.textContent : '';
      lb.classList.add('open');
      document.body.style.overflow = 'hidden';
      lb.querySelector('.x').focus();
    };
    var close = function(){
      lb.classList.remove('open');
      lbimg.src = '';
      document.body.style.overflow = '';
      if(opener) opener.focus();
    };
    each(document.querySelectorAll('.media:not(.vid)'), function(fig){
      fig.addEventListener('click', function(){ if(!fig.classList.contains('empty')) open(fig); });
      fig.addEventListener('keydown', function(e){
        if((e.key === 'Enter' || e.key === ' ') && !fig.classList.contains('empty')){ e.preventDefault(); open(fig); }
      });
    });
    lb.addEventListener('click', function(e){ if(e.target !== lbimg) close(); });
    document.addEventListener('keydown', function(e){
      if(e.key === 'Escape' && lb.classList.contains('open')) close();
    });
  }

  /* ---------- 8. filter di halaman Work ---------- */
  var filter = document.querySelector('.filter');
  if(filter){
    var items = document.querySelectorAll('[data-cat]');
    each(filter.querySelectorAll('button'), function(btn){
      btn.addEventListener('click', function(){
        var want = btn.getAttribute('data-filter');
        each(filter.querySelectorAll('button'), function(b){ b.setAttribute('aria-pressed','false'); });
        btn.setAttribute('aria-pressed','true');
        each(items, function(it){
          var show = (want === 'all') || (it.getAttribute('data-cat') === want);
          it.classList.toggle('hidden', !show);
        });
      });
    });
  }
})();
